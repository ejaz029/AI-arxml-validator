# ai/__init__.py
# This file makes 'ai' a recognized package
